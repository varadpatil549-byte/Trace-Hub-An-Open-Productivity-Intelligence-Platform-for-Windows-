# TraceHub — Windows Activity Intelligence Skill

> **An AI-ready Windows activity collector that turns workstation activity into structured, analyzable data.**

## Overview

**TraceHub** is a Windows-based activity intelligence solution designed to capture meaningful workstation activity and convert it into a structured CSV dataset that can be consumed by an AI agent, dashboard, or analytics workflow.

TraceHub captures application usage, browser metadata, idle periods, activity classifications, user/workstation identity, and visible background applications — while intentionally avoiding keystrokes, mouse coordinates, screenshots, passwords, and page contents.

The package is designed as an **AI Build / Skill**:

```text
TraceHub.exe
      ↓
Windows Activity Collection
      ↓
TraceHub_Activity.csv
      ↓
SKILL.md
      ↓
AI Agent / Analytics / Dashboard
```

The executable is the collection engine. `SKILL.md` provides the AI-facing instructions for understanding and analyzing the generated dataset.

---

## What TraceHub Does

TraceHub continuously samples the active Windows workstation and records information such as:

- 👤 Username
- 💻 Computer name
- 🕒 Timestamp, date, and time
- 🪟 Foreground application
- ⚙️ Process name and process ID
- 📝 Active window title
- 🟢 Active / 🔴 Idle status
- ⏱️ Idle duration
- 🌐 Browser website name
- 📄 Browser page title
- 🔗 Website URL/domain when exposed by Windows UI Automation
- 🗂️ Application and website category
- 📊 Productivity classification
- 🧩 Visible background/open applications
- 🔢 Background application count
- 📌 Event type
- 🛑 Termination reason

The resulting dataset is designed to support AI-assisted questions such as:

- What applications were used during a particular period?
- How much time was spent in active versus idle states?
- Which categories of applications were most frequently used?
- Which websites were accessed?
- What was the activity pattern for a specific user or workstation?
- What applications were open in the background?
- What productivity patterns can be observed from the recorded activity?
- When did tracking start or stop?

---

## Key Capabilities

### 🖥️ Windows Activity Collection

TraceHub is built specifically for Windows and collects workstation-level activity through Windows APIs and system information.

### 📊 Structured Activity Dataset

All captured events are written into:

`TraceHub_Activity.csv`

The CSV is intentionally structured so it can be consumed by:

- AI agents
- Power BI
- Excel
- Python
- SQL/data pipelines
- Custom HTML dashboards
- Other analytics tools

### 🌐 Browser Intelligence

For supported browsers, TraceHub attempts to identify:

- Website
- Page title
- URL
- Domain

Website detection is **best effort** and depends on metadata exposed by the browser through Windows UI Automation.

### 🧠 Activity Classification

TraceHub categorizes applications and websites into areas such as:

- Microsoft Office
- AI & Productivity
- Development
- Communication
- ERP & Business
- File & Productivity
- Design & Collaboration
- Browser
- Media
- Gaming
- Productivity
- Knowledge & Research
- Social
- Entertainment
- Shopping
- Internal Business

Activity can also be classified as:

- `PRODUCTIVE`
- `NON-PRODUCTIVE`
- `NEUTRAL`
- `UNKNOWN`

These classifications are intended as analytical signals rather than absolute measurements of employee performance.

### 🪟 Background Application Visibility

TraceHub records visible user-facing background applications rather than attempting to report every Windows system process.

This provides a more useful picture of the applications that were open during a user's working session.

### 🛑 Controlled Termination

TraceHub includes a visible **Stop Tracking** control.

When tracking is manually stopped, the dataset can record a termination event and reason so that an AI agent can distinguish a normal activity sample from the end of a tracking session.

---

## Package Structure

```text
TraceHub-Skill/
│
├── SKILL.md
├── TraceHub.exe
├── TraceHub_Config.json
├── README.md
├── LICENSE.txt
│
└── Examples/
    └── sample_activity.csv
```

### File Responsibilities

| File | Purpose |
|---|---|
| `TraceHub.exe` | Windows activity collection engine |
| `TraceHub_Config.json` | External configuration for collection behavior and classifications |
| `SKILL.md` | AI-facing instructions for interpreting TraceHub data |
| `README.md` | Product/package documentation |
| `Examples/sample_activity.csv` | Example dataset for understanding the output structure |

---

## How It Works

### 1. Run TraceHub

Launch `TraceHub.exe` on the Windows workstation.

### 2. TraceHub Collects Activity

The application periodically samples the workstation and identifies the active application, idle state, browser metadata, classifications, and visible background applications.

### 3. Data Is Written to CSV

TraceHub generates:

```text
TraceHub_Activity.csv
```

The CSV is stored beside the executable when running as a packaged EXE.

### 4. AI Reads the Dataset

`SKILL.md` provides the AI agent with the context required to understand:

- what each field means
- how activity should be interpreted
- how users/workstations should be identified
- how idle and active states should be handled
- how classifications should be interpreted
- what limitations should be considered

### 5. Analytics Can Be Built on Top

The same dataset can also become the source for dashboards, reports, automation workflows, or additional AI analysis.

---

## Configuration

TraceHub supports an external:

```text
TraceHub_Config.json
```

This allows supported behavior and classification rules to be adjusted without rebuilding the executable.

The configuration can be used for items such as:

- Sampling interval
- Idle threshold
- Website overrides
- Application overrides

The configuration file should remain beside `TraceHub.exe`.

---

## AI Skill Layer

The important distinction in this package is:

### `TraceHub.exe` = Collector

The executable performs the actual Windows activity collection.

### `SKILL.md` = AI Instruction Layer

The skill teaches an AI agent how to work with TraceHub's output.

It does **not** replace the collector.

It explains how the AI should reason over the generated activity data and how to answer questions without making unsupported conclusions.

This separation allows the same collector to be used with different AI agents, dashboards, and analytical workflows.

---

## Example AI Questions

Once `TraceHub_Activity.csv` is available, an AI agent using the skill can support questions such as:

> "Show me the activity pattern for this workstation today."

> "How much idle activity was recorded?"

> "Which application categories were used most frequently?"

> "What websites were detected during the session?"

> "What was the user's activity between 10 AM and 12 PM?"

> "Which applications were open in the background?"

> "Identify periods of continuous idle activity."

> "Compare activity across two users or workstations."

> "Summarize the day's recorded activity."

> "Explain the termination events recorded in the dataset."

The exact answer depends on the data available in the CSV.

---

## Privacy by Design

TraceHub is intentionally focused on **activity metadata**, not surveillance of user content.

The collector does **not** record:

- ❌ Keystrokes
- ❌ Mouse coordinates
- ❌ Screenshots
- ❌ Passwords
- ❌ Page contents

Browser information is limited to website/page metadata that Windows UI Automation exposes to the application.

This makes TraceHub suitable for activity analytics where the goal is to understand **application and workstation activity**, rather than capture the contents of a user's work.

---

## Important Limitations

TraceHub should be treated as an **activity intelligence and analytics tool**, not as a definitive employee-performance measurement system.

Important considerations:

1. Browser URL detection is best effort.
2. Website/page metadata depends on what the browser exposes through Windows UI Automation.
3. Productivity classifications are rule-based and should be interpreted as analytical indicators.
4. An application being open does not necessarily mean that the user was actively working in it.
5. Background applications represent visible user-facing applications, not every Windows process.
6. TraceHub is Windows-only.
7. The AI agent should not infer facts that are not supported by the recorded dataset.

---

## Deployment

`TraceHub.exe` is designed to be distributed as a standalone Windows executable.

No Python source code is required for the end user.

The package can therefore be distributed as:

```text
TraceHub.exe
TraceHub_Config.json
SKILL.md
README.md
Examples/
```

Automatic startup, scheduled execution, or enterprise deployment can be implemented separately through the organization's Windows deployment mechanism without changing the TraceHub data model.

---

## Intended Use

TraceHub can serve as a foundation for:

- Workforce activity analytics
- Application usage analysis
- Productivity reporting
- Workstation utilization analysis
- AI-powered activity summaries
- Operational dashboards
- Activity pattern detection
- Process and workflow analysis
- Custom enterprise analytics

The generated CSV provides a common data layer that can be consumed by both traditional analytics and AI systems.

---

## Why This Is an AI Build / Skill

TraceHub combines three layers:

```text
┌───────────────────────────────┐
│        TraceHub.exe           │
│  Windows Activity Collector   │
└───────────────┬───────────────┘
                │
                ▼
┌───────────────────────────────┐
│     TraceHub_Activity.csv     │
│      Structured Activity      │
│             Data              │
└───────────────┬───────────────┘
                │
                ▼
┌───────────────────────────────┐
│          SKILL.md             │
│     AI Interpretation Layer   │
└───────────────┬───────────────┘
                │
                ▼
┌───────────────────────────────┐
│       AI / Analytics Layer    │
│  Questions • Insights •       │
│  Summaries • Analysis         │
└───────────────────────────────┘
```

This architecture separates **data collection** from **AI reasoning**, allowing TraceHub to act as a reusable activity-data capability for AI workflows.

---

## Quick Start

1. Copy the TraceHub package to a Windows workstation.
2. Keep `TraceHub.exe` and `TraceHub_Config.json` in the same folder.
3. Launch `TraceHub.exe`.
4. Allow TraceHub to collect activity.
5. Stop tracking using the visible control when required.
6. Open the generated `TraceHub_Activity.csv`.
7. Use the dataset with the accompanying `SKILL.md` for AI analysis.

---

## License & Intellectual Property

TraceHub is proprietary software.

Copyright © 2026 Varad Patil. All Rights Reserved.

The TraceHub executable, underlying implementation, and associated documentation
are not licensed for unauthorized copying, modification, redistribution,
reverse engineering, or commercial distribution.

The executable is distributed as a compiled application; the underlying source
code is not included in this package.

See `LICENSE.txt` for the complete license notice.

---

## Version

**TraceHub v0.4**

Windows activity collector / AI-ready activity intelligence package.

---

## Summary

**TraceHub turns Windows workstation activity into structured data that an AI agent can understand and analyze.**

The executable handles collection.

The CSV provides the data.

The skill provides the intelligence layer.

Together, they form a reusable **AI Build / Skill for Windows activity intelligence**.
