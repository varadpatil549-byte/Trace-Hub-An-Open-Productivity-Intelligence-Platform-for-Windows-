# TraceHub Skill

## Purpose

TraceHub is a Windows activity-collection application designed to capture workstation activity and produce a structured CSV dataset for AI-assisted analysis, reporting, productivity analysis, and operational insights.

The TraceHub package has two primary layers:

1. **TraceHub.exe** — the local Windows activity collector.
2. **SKILL.md** — the instruction layer that tells an AI agent what TraceHub is, what data it produces, how to interpret that data, and how to use it responsibly.

TraceHub.exe is the execution component. SKILL.md does not replace the executable and does not itself collect activity.

---

## Platform

- Windows only.
- TraceHub is designed to run locally on the user's Windows workstation.
- The executable can be distributed without exposing the Python source code.

---

## Package Structure

A standard TraceHub skill package contains:

```text
TraceHub-Skill/
├── SKILL.md
├── TraceHub.exe
├── TraceHub_Config.json
└── Examples/
    └── sample_activity.csv
```

### Component responsibilities

| Component | Responsibility |
|---|---|
| `TraceHub.exe` | Collects workstation activity and generates the CSV |
| `TraceHub_Config.json` | Controls supported deployment/configuration overrides |
| `SKILL.md` | Teaches the AI agent how to understand and use TraceHub |
| `Examples/` | Provides an example of the generated activity dataset |

---

# TraceHub Execution

TraceHub.exe is the actual activity collector.

When launched on a Windows workstation, it:

1. Identifies the current Windows username.
2. Identifies the computer/system name.
3. Continuously samples foreground activity.
4. Detects active or idle state.
5. Captures the foreground application and process information.
6. Captures browser website metadata when Windows UI Automation exposes it.
7. Classifies applications and websites.
8. Records productivity classification.
9. Records visible/open background user applications.
10. Writes activity records to `TraceHub_Activity.csv`.

The executable contains the collection logic. The AI agent should not attempt to reproduce or simulate the collection logic.

---

# Output Dataset

TraceHub generates:

```text
TraceHub_Activity.csv
```

The CSV is created in the same directory as the executable when running the packaged EXE.

The dataset contains the following fields:

| Field | Meaning |
|---|---|
| `Timestamp` | Date and time of the recorded event |
| `Date` | Activity date |
| `Time` | Activity time |
| `Username` | Windows username of the user running TraceHub |
| `ComputerName` | Windows computer/system name |
| `ActivityStatus` | Current activity state, such as ACTIVE or IDLE |
| `IdleSeconds` | Duration of detected Windows idle time |
| `ForegroundApplication` | Application currently in the foreground |
| `ProcessName` | Foreground process executable name |
| `PID` | Process ID |
| `WindowTitle` | Foreground window title |
| `ApplicationCategory` | Category assigned to the foreground application |
| `Productivity` | Productivity classification |
| `WebsiteName` | Detected website name, when available |
| `PageTitle` | Detected browser page/title metadata, when available |
| `WebsiteURL` | Best-effort URL exposed by Windows UI Automation |
| `WebsiteDomain` | Website domain |
| `WebsiteCategory` | Website classification |
| `BackgroundOpenApps` | Visible/open user applications detected in the background |
| `BackgroundAppCount` | Number of detected background user applications |
| `EventType` | Type of dataset event |
| `TerminationReason` | Reason recorded when the user manually terminates tracking |

---

# Activity Sampling

The collector uses a configurable sampling interval.

The standard configuration uses:

```text
Sample interval: 5 seconds
```

The idle threshold is configurable through the deployment configuration.

For example, if the configured idle threshold is 120 seconds, the activity status becomes `IDLE` when detected Windows idle time reaches or exceeds 120 seconds.

Do not assume that every deployment uses the same idle threshold. Read the active configuration when the value is required for analysis.

---

# Activity Classification

TraceHub classifies applications and websites into categories and assigns productivity status.

Common application categories include:

- Microsoft Office
- AI & Productivity
- Development
- Communication
- ERP & Business
- File & Productivity
- Design & Collaboration
- Browser
- Media / Gaming
- System & Utilities

Common website categories include:

- AI & Productivity
- Productivity
- Communication
- Development
- ERP & Business
- Knowledge & Research
- Design & Collaboration
- Social
- Entertainment
- Shopping

The classification is intended for operational/productivity analysis. It should not automatically be treated as a definitive judgment of employee performance.

---

# Productivity Values

When analyzing the `Productivity` field, preserve the values recorded by TraceHub.

Typical classifications are:

- `PRODUCTIVE`
- `NON-PRODUCTIVE`
- `NEUTRAL`

Some applications, especially browsers, may initially have no direct productivity classification until the associated website is identified.

When website-level information is available, use the website classification alongside the application information.

---

# Website Detection

TraceHub can capture browser website metadata through Windows UI Automation when the required information is exposed by the browser.

Possible fields include:

- Website name
- Page title
- URL
- Domain
- Website category

Website capture is therefore **best effort**.

The AI agent must not assume that every browser activity row contains a website URL or page title.

A browser process being recorded does not necessarily mean a specific website was successfully identified.

---

# Background Applications

TraceHub records visible/open user applications detected in the background.

These values are intended to provide additional workstation context.

The AI agent should distinguish:

- `ForegroundApplication` — the application currently being used/in focus.
- `BackgroundOpenApps` — other visible/open user applications detected in the background.

Background applications should not automatically be interpreted as applications actively being used.

---

# Event Types

Normal tracking records use:

```text
ACTIVITY
```

When the user manually stops tracking, TraceHub can write a termination record using:

```text
USER_TERMINATION
```

The `TerminationReason` field can contain the reason recorded by the TraceHub interface.

When calculating working/activity duration, do not treat a `USER_TERMINATION` record as a normal activity sample.

---

# User and Computer Identification

TraceHub records both:

```text
Username
ComputerName
```

These fields are important for multi-user or multi-machine analysis.

When analyzing consolidated TraceHub datasets:

- Use `Username` to identify the user.
- Use `ComputerName` to identify the workstation.
- Use `Timestamp` / `Date` / `Time` for temporal analysis.

Do not infer an employee's identity from the computer name alone when a `Username` value is available.

---

# Configuration

`TraceHub_Config.json` provides deployment-level configuration without requiring the executable to be rebuilt.

Supported configuration areas include:

### Sampling

```text
sample_interval_seconds
idle_threshold_seconds
```

### Website overrides

```text
website_overrides
```

These can define the desired category and productivity classification for specific website domains.

### Application overrides

```text
application_overrides
```

These can define the desired category and productivity classification for specific process names.

The configuration file should remain alongside `TraceHub.exe`.

If configuration is changed, restart TraceHub so the new deployment configuration is applied.

Do not modify the executable merely to change a supported classification or timing configuration.

---

# AI Agent Instructions

When an AI agent is provided access to TraceHub output, it should:

1. Treat `TraceHub_Activity.csv` as the primary activity dataset.
2. Inspect the column names before performing analysis.
3. Use `Username` and `ComputerName` to distinguish users and workstations.
4. Use timestamps for date/time filtering.
5. Use `ActivityStatus` and `IdleSeconds` for inactivity analysis.
6. Use `ForegroundApplication` and `ProcessName` for application analysis.
7. Use `WebsiteName`, `PageTitle`, `WebsiteDomain`, and `WebsiteURL` when website-level analysis is required.
8. Use `Productivity` for productive/non-productive analysis.
9. Use `ApplicationCategory` and `WebsiteCategory` for category-level analysis.
10. Treat `BackgroundOpenApps` as contextual information rather than proof of active usage.
11. Exclude or separately handle `USER_TERMINATION` events when calculating activity durations.
12. Clearly state when data is missing or website detection was unavailable.
13. Preserve the distinction between recorded activity and inferred conclusions.

---

# Example Questions the Skill Should Support

The AI agent should be able to use TraceHub data to answer questions such as:

### User-level analysis

- Who was active during a particular period?
- What applications did a user spend time using?
- How much idle time was recorded for a user?
- What websites were recorded for a user?
- What was the user's productive vs non-productive activity?

### Team-level analysis

- Which users recorded the most productive activity?
- Which users had the highest idle time?
- Which applications were most commonly used?
- Which websites were most commonly recorded?
- What percentage of activity was classified as productive?
- What were the most common non-productive categories?

### Time-based analysis

- What happened between 9:00 AM and 11:00 AM?
- How did activity change throughout the day?
- What was the longest recorded idle period?
- What applications were active during a specific time window?

### Application / website analysis

- Which applications were used most frequently?
- Which website domains were recorded most frequently?
- How much activity was associated with communication tools?
- How much activity was associated with development tools?
- Which categories contained the most non-productive activity?

---

# Interpretation Rules

The AI agent must avoid overstating what TraceHub data proves.

### Do

- Say "TraceHub recorded..."
- Say "The dataset shows..."
- Use recorded timestamps and classifications.
- Identify missing or incomplete website metadata.
- Separate measured activity from interpretation.

### Do not

- Claim that a person was continuously working merely because TraceHub was running.
- Treat an open background application as active usage.
- Treat a `NON-PRODUCTIVE` classification as proof that the employee was unproductive overall.
- Infer intent from application or website usage.
- Assume missing website metadata means the user was not browsing.
- Invent activity that is not present in the CSV.

---

# Privacy and Data Handling

TraceHub is designed to collect workstation activity metadata.

The collector does not intentionally capture:

- Keystrokes
- Mouse coordinates
- Screenshots
- Passwords
- Full webpage contents

Website information is limited to browser metadata that Windows UI Automation exposes to the collector.

The AI agent should handle TraceHub data as workplace activity information and should not expose or infer sensitive information beyond what is required for the requested analysis.

---

# Operational Requirements

Before analyzing TraceHub data, verify:

1. TraceHub has been run on the relevant Windows workstation.
2. `TraceHub_Activity.csv` exists.
3. The CSV contains records for the requested period.
4. The requested user/workstation can be identified.
5. The relevant timestamp range is present.

If the CSV is missing, empty, locked, or does not contain the requested period, report that limitation instead of inventing results.

---

# Startup and Deployment

TraceHub.exe is a standalone Windows executable.

The AI skill does not require a wrapper to perform activity collection.

For a single workstation, the user or deployment administrator can launch TraceHub.exe.

If an organization later requires automatic launch at Windows login/startup or automatic stop at a defined time, that can be implemented as a Windows deployment/scheduling mechanism without changing the core TraceHub data model or the AI skill.

The skill should not assume that TraceHub automatically starts unless the deployment explicitly provides such a mechanism.

---

# Multi-User / Multi-Computer Use

Each workstation can run its own copy of TraceHub.exe and generate its own local CSV.

Because the CSV includes:

- `Username`
- `ComputerName`
- `Timestamp`

multiple TraceHub datasets can be distinguished when they are later consolidated.

A future centralized deployment may collect these datasets into a shared repository, database, API, or other central data source. The current TraceHub executable does not require such infrastructure to operate locally.

---

# Limitations

TraceHub is a Windows activity collector and is not a complete employee-performance measurement system.

Important limitations include:

- Windows-only operation.
- Website detection depends on information exposed through Windows UI Automation.
- Browser activity may not always include a URL or page title.
- Background application detection does not prove active usage.
- Productivity classifications are rule-based and should be interpreted as classifications rather than definitive performance judgments.
- The presence of TraceHub running does not by itself prove that a person was continuously working.
- Local CSV data represents only the workstation on which TraceHub was running.

---

# Agent Response Principles

When answering questions using TraceHub data:

1. Be data-driven.
2. Use the actual recorded fields.
3. Respect the requested time period.
4. Identify the relevant user and computer.
5. Distinguish active, idle, foreground, and background activity.
6. Explain missing or incomplete data.
7. Avoid unsupported conclusions.
8. Provide calculations when requested.
9. Prefer concise operational summaries for management questions.
10. Never fabricate records or activity.

---

## Summary

TraceHub has a simple separation of responsibilities:

```text
TraceHub.exe
    ↓
Collect workstation activity
    ↓
TraceHub_Activity.csv
    ↓
SKILL.md
    ↓
AI understands and analyzes the dataset
```

TraceHub.exe is the collector.

SKILL.md is the AI instruction layer.

The CSV is the source of recorded activity data.
